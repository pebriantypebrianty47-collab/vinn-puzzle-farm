plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.vinn.puzzlefarm"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.vinn.puzzlefarm"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-prototype"
    }
}
