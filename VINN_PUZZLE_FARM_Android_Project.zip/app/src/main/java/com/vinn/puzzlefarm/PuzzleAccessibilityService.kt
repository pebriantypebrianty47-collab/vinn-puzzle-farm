package com.vinn.puzzlefarm

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class PuzzleAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Placeholder only: no tile recognition, tapping, or ad bypass is implemented.
        // Next development step: user-consented screen analysis and safe game-state detection.
    }
    override fun onInterrupt() {}
}
