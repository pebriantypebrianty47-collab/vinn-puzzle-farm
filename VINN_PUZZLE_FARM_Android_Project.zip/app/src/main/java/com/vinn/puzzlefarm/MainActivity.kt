package com.vinn.puzzlefarm

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color
import android.view.ViewGroup

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(Color.rgb(226, 247, 216))
        }
        val title = TextView(this).apply {
            text = "VINN PUZZLE FARM"
            textSize = 26f
            setTextColor(Color.rgb(35, 90, 40))
            gravity = Gravity.CENTER
        }
        val status = TextView(this).apply {
            text = "Prototype Android 14\nPanel dan izin kontrol belum diaktifkan."
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(8, 20, 8, 24)
        }
        fun button(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
        layout.addView(title, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        layout.addView(status, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        layout.addView(button("Izinkan Floating Panel") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            } else {
                startService(Intent(this, FloatingPanelService::class.java))
            }
        })
        layout.addView(button("Buka pengaturan Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        layout.addView(button("Mulai panel (jika izin sudah aktif)") {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, FloatingPanelService::class.java))
                status.text = "Panel diminta untuk dijalankan. Ini masih prototipe."
            } else {
                status.text = "Aktifkan izin Floating Panel terlebih dahulu."
            }
        })
        setContentView(layout)
    }
}
