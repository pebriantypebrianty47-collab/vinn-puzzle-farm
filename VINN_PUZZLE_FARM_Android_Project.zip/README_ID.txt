VINN PUZZLE FARM — PROYEK AWAL ANDROID

Status:
- Ini adalah SOURCE PROJECT/prototipe, BUKAN file APK siap instal.
- Belum ada AI pembaca ubin dan belum ada Auto Play yang benar-benar mengendalikan game.
- Floating panel dan layar permintaan izin disediakan sebagai kerangka awal.
- Deteksi iklan belum diimplementasikan; aplikasi tidak mengeklik atau melewati iklan.
- Panel dapat tertutup/terhalang oleh iklan layar penuh atau pembatasan Android.

Cara membangun:
1. Proyek ini perlu dibuka di Android Studio pada komputer.
2. Gunakan Android SDK 35 dan JDK 17.
3. Tunggu Gradle Sync selesai.
4. Pilih Build > Build APK(s).
5. Uji hasilnya di perangkat Android 14.

Catatan keamanan:
Aktifkan Accessibility hanya setelah memahami izin yang diminta. Proyek ini belum mengirim data keluar perangkat dan tidak memiliki kode untuk mem-bypass iklan.
